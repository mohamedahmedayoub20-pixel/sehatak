<?php

include "includes/auth.php";

requireLogin();
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
</head>

<body>
    <a href="index.php">Home</a>
    <p> Hello, <?php echo $_SESSION['user_email']; ?> | <?php echo $_SESSION['user_type']; ?> </p>

    <a href="logout.php">Logout</a>

    <h1>Services</h1>
</body>

</html>