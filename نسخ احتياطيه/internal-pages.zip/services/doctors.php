<?php
include "../includes/auth.php";

$language = "ar";
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ar'])) {
    $language = $_GET['lang'];
}
?>

<!DOCTYPE html>
<html lang="<?php echo $language; ?>" dir="<?php echo $language === 'ar' ? 'rtl' : 'ltr'; ?>">

<head>
    <meta charset="UTF-8">
    <!-- إعدادات متجاوبة مع جميع الشاشات -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>خدمات الأطباء - موقع صحتك</title>
    <?php if ($language === 'ar') { ?>
        <link rel="stylesheet" href="../css/hom-ar.css">

        <link rel="stylesheet" href="../css/services/doctors-ar.css">
    <?php } else { ?>
        <link rel="stylesheet" href="../css/hom.css">

        <link rel="stylesheet" href="../css/services/doctors.css">
    <?php } ?>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
</head>

<body id="mainBody">
    <!-- الصفحة الرئيسية -->
    <div id="homePage">
        <?php if ($language === 'ar') { ?>

            <header>
                <div class="logo"><i class="fas fa-heartbeat"></i><a href="../index.php">صحتك</a> </div>
                <div class="search-container">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" placeholder="ابحث عن الدكاترة بالاسم..">
                </div>

                <div class="auth-buttons" style="display: flex; align-items: center; gap: 15px;">

                    <div class="lang-dropdown">
                        <button class="lang-btn">
                            <?php echo ($language == 'ar') ? '🇪🇬 العربية' : '🇬🇧 English'; ?>
                            <i class="fas fa-chevron-down" style="font-size: 0.8rem; margin-right: 5px;"></i>
                        </button>
                        <div class="lang-content">
                            <a href="?lang=ar">🇪🇬 العربية</a>
                            <a href="?lang=en">🇬🇧 English</a>
                        </div>
                    </div>

                    <?php if (isLoggedIn()): ?>
                        <p style="margin: 0; font-size: 0.9rem;">
                            مرحباً، <?php echo $_SESSION['user_name']; ?> | <?php echo $_SESSION['user_type']; ?>
                        </p>
                        <a href="logout.php?lang=<?php echo $language ?>" class="btn btn-logout">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="#" class="btn btn-guest">تصفح الموقع</a>
                        <a href="login.php?lang=<?php echo $language ?>" class="btn btn-login">دخول المرضى</a>
                    <?php endif; ?>
                </div>
            </header>

            <main>
                <div class="hero">
                    <div class="icon-circle">🩺</div>
                    <h1>ابحث عن طبيبك</h1>
                    <p>موقع صحتك</p>
                </div>
                <!-- أزرار التصفية حسب التخصص -->
                <section class="filters">
                    <h3>تصفية حسب التخصص</h3>
                    <div class="filter-buttons">
                        <button class="filter-btn active" onclick="filterSelection('all', this)">جميع الأطباء</button>
                        <button class="filter-btn" onclick="filterSelection('اطفال', this)">اخصائي الأطفال</button>
                        <button class="filter-btn" onclick="filterSelection('اعصاب', this)">اخصائي أعصاب</button>
                        <button class="filter-btn" onclick="filterSelection('جلدية', this)">اخصائي جلدية</button>
                        <button class="filter-btn" onclick="filterSelection('قلب', this)">اخصائي قلب</button>
                        <button class="filter-btn" onclick="filterSelection('عظام', this)">جراح عظام</button>
                        <button class="filter-btn" onclick="filterSelection('عام', this)">طبيب عام</button>
                        <button class="filter-btn" onclick="filterSelection('الولادة', this)">اخصائي اطفال وحديثي الولادة</button>
                        <button class="filter-btn" onclick="filterSelection('اذن وحنجرة', this)">اخصائي انف و اذن وحنجرة</button>
                        <button class="filter-btn" onclick="filterSelection('طبيعي', this)">اخصائي علاج طبيعي</button>
                        <button class="filter-btn" onclick="filterSelection('دموية', this)"> اخصائي قلب واوعية دموية</button>
                    </div>
                </section>

                <!-- شبكة بطاقات الأطباء -->
                <div class="doctor-grid" id="doctorGrid">
                    <!-- د. سارة محمد عبدالرحمن -->
                    <div class="doctor-card" data-type="قلب" data-name="سارة محمد عبدالرحمن">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. سارة محمد عبدالرحمن</h3>
                            <p class="spec">اخصائي قلب</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(127 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مصر الجديدة | 🕒 15 سنة خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">500 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('سارة محمد عبدالرحمن')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('سارة محمد عبدالرحمن')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. نهي يوسف محمود -->
                    <div class="doctor-card" data-type="عام" data-name="نهي يوسف محمود">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. نهي يوسف محمود</h3>
                            <p class="spec">طبيب عام</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(234 تقييم)</span></p>
                            <p class="meta">📍 الإسكندرية، ميامي | 🕒 8 سنوات خبرة</p>
                            <p class="price-status">● متاح الآن <span class="price">350 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('نهي يوسف محمود')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('نهي يوسف محمود')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. عمر محمد حجاب -->
                    <div class="doctor-card" data-type="قلب" data-name="عمر محمد حجاب">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. عمر محمد حجاب</h3>
                            <p class="spec">اخصائي قلب</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(178 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، الزمالك | 🕒 20 سنة خبرة</p>
                            <p class="price-status">● متاح الآن <span class="price">650 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('عمر محمد حجاب')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('عمر محمد حجاب')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. هدي كمال فؤاد -->
                    <div class="doctor-card" data-type="اطفال" data-name="هدي كمال فؤاد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. هدي كمال فؤاد</h3>
                            <p class="spec">اخصائي أطفال</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(192 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 11 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">450 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('هدي كمال فؤاد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('هدي كمال فؤاد')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مروة اشرف يوسف -->
                    <div class="doctor-card" data-type="طبيعي" data-name="مروة اشرف يوسف">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مروة اشرف يوسف</h3>
                            <p class="spec">اخصائي علاج طبيعي</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(160 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 6 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">400 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مروة اشرف يوسف')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مروة اشرف يوسف')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. احمد حسن ابراهيم -->
                    <div class="doctor-card" data-type="اطفال" data-name="احمد حسن ابراهيم">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. احمد حسن ابراهيم</h3>
                            <p class="spec">اخصائي أطفال</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(203 تقييم)</span></p>
                            <p class="meta">📍 الإسكندرية، سموحة | 🕒 12 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">400 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('احمد حسن ابراهيم')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('احمد حسن ابراهيم')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مني علي السيد -->
                    <div class="doctor-card" data-type="جلدية" data-name="مني علي السيد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مني علي السيد</h3>
                            <p class="spec">اخصائي جلدية</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(156 تقييم)</span></p>
                            <p class="meta">📍 الجيزة، المهندسين | 🕒 10 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">600 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مني علي السيد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مني علي السيد')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. ياسمين احمد فؤاد -->
                    <div class="doctor-card" data-type="الولادة" data-name="ياسمين احمد فؤاد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. ياسمين احمد فؤاد</h3>
                            <p class="spec">اخصائي اطفال و حديثي الولادة</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(150 تقييم)</span></p>
                            <p class="meta">📍 الجيزة، المهندسين | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">500 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('ياسمين احمد فؤاد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('ياسمين احمد فؤاد')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. محمود سعيد احمد -->
                    <div class="doctor-card" data-type="عظام" data-name="محمود سعيد احمد">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. محمود سعيد احمد</h3>
                            <p class="spec">جراح عظام</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(89 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مدينة نصر | 🕒 18 سنة خبرة</p>
                            <p class="price-status">● متاح بعد 3 أيام <span class="price">700 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('محمود سعيد احمد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('محمود سعيد احمد')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مصطفي خالد عبداللة -->
                    <div class="doctor-card" data-type="اذن وحنجرة" data-name="مصطفي خالد عبداللة">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مصطفي خالد عبداللة</h3>
                            <p class="spec"> اخصائي انف واذن وحنجرة</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(120 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مدينة نصر | 🕒 10 سنة خبرة</p>
                            <p class="price-status">● متاح بعد 3 أيام <span class="price">600 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مصطفي خالد عبداللة')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مصطفي خالد عبداللة')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. خالد فتحي عبدالله -->
                    <div class="doctor-card" data-type="اعصاب" data-name="خالد فتحي عبدالله">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. خالد فتحي عبدالله</h3>
                            <p class="spec">اخصائي أعصاب</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(145 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">800 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('خالد فتحي عبدالله')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('خالد فتحي عبدالله')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. شريف سامي حسن -->
                    <div class="doctor-card" data-type="دموية" data-name="شريف سامي حسن">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. شريف سامي حسن</h3>
                            <p class="spec">اخصائي قلب واوعية دموية</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(160 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">900 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('شريف سامي حسن')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('شريف سامي حسن')">عرض الملف</button>
                        </div>
                    </div>
                </div>
            </main>
        <?php } else { ?>
            <!-- رأس الصفحة -->
            <header>
                <div class="logo"><i class="fas fa-heartbeat"></i><a href="../index.php">Sehatak</a> </div>
                <div class="search-container">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" placeholder="Doctor search using name, specialization, etc.">
                </div>

                <div class="auth-buttons" style="display: flex; align-items: center; gap: 15px;">

                    <div class="lang-dropdown">
                        <button class="lang-btn">
                            <?php echo ($language == 'ar') ? '🇪🇬 العربية' : '🇬🇧 English'; ?>
                            <i class="fas fa-chevron-down" style="font-size: 0.8rem; margin-right: 5px;"></i>
                        </button>
                        <div class="lang-content">
                            <a href="?lang=ar">🇪🇬 العربية</a>
                            <a href="?lang=en">🇬🇧 English</a>
                        </div>
                    </div>

                    <?php if (isLoggedIn()): ?>
                        <p style="margin: 0; font-size: 0.9rem;">
                            مرحباً، <?php echo $_SESSION['user_name']; ?> | <?php echo $_SESSION['user_type']; ?>
                        </p>
                        <a href="logout.php?lang=<?php echo $language ?>" class="btn btn-logout">Logout</a>
                    <?php else: ?>
                        <a href="#" class="btn btn-guest">Browse Website</a>
                        <a href="login.php?lang=<?php echo $language ?>" class="btn btn-login">Patient Login</a>
                    <?php endif; ?>
                </div>
            </header>

            <main>
                <div class="hero">
                    <div class="icon-circle">🩺</div>
                    <h1>ابحث عن طبيبك</h1>
                    <p>موقع صحتك</p>
                </div>
                <!-- أزرار التصفية حسب التخصص -->
                <section class="filters">
                    <h3>تصفية حسب التخصص</h3>
                    <div class="filter-buttons">
                        <button class="filter-btn active" onclick="filterSelection('all', this)">جميع الأطباء</button>
                        <button class="filter-btn" onclick="filterSelection('اطفال', this)">اخصائي الأطفال</button>
                        <button class="filter-btn" onclick="filterSelection('اعصاب', this)">اخصائي أعصاب</button>
                        <button class="filter-btn" onclick="filterSelection('جلدية', this)">اخصائي جلدية</button>
                        <button class="filter-btn" onclick="filterSelection('قلب', this)">اخصائي قلب</button>
                        <button class="filter-btn" onclick="filterSelection('عظام', this)">جراح عظام</button>
                        <button class="filter-btn" onclick="filterSelection('عام', this)">طبيب عام</button>
                        <button class="filter-btn" onclick="filterSelection('الولادة', this)">اخصائي اطفال وحديثي الولادة</button>
                        <button class="filter-btn" onclick="filterSelection('اذن وحنجرة', this)">اخصائي انف و اذن وحنجرة</button>
                        <button class="filter-btn" onclick="filterSelection('طبيعي', this)">اخصائي علاج طبيعي</button>
                        <button class="filter-btn" onclick="filterSelection('دموية', this)"> اخصائي قلب واوعية دموية</button>
                    </div>
                </section>

                <!-- شبكة بطاقات الأطباء -->
                <div class="doctor-grid" id="doctorGrid">
                    <!-- د. سارة محمد عبدالرحمن -->
                    <div class="doctor-card" data-type="قلب" data-name="سارة محمد عبدالرحمن">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. سارة محمد عبدالرحمن</h3>
                            <p class="spec">اخصائي قلب</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(127 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مصر الجديدة | 🕒 15 سنة خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">500 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('سارة محمد عبدالرحمن')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('سارة محمد عبدالرحمن')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. نهي يوسف محمود -->
                    <div class="doctor-card" data-type="عام" data-name="نهي يوسف محمود">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. نهي يوسف محمود</h3>
                            <p class="spec">طبيب عام</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(234 تقييم)</span></p>
                            <p class="meta">📍 الإسكندرية، ميامي | 🕒 8 سنوات خبرة</p>
                            <p class="price-status">● متاح الآن <span class="price">350 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('نهي يوسف محمود')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('نهي يوسف محمود')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. عمر محمد حجاب -->
                    <div class="doctor-card" data-type="قلب" data-name="عمر محمد حجاب">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. عمر محمد حجاب</h3>
                            <p class="spec">اخصائي قلب</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(178 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، الزمالك | 🕒 20 سنة خبرة</p>
                            <p class="price-status">● متاح الآن <span class="price">650 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('عمر محمد حجاب')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('عمر محمد حجاب')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. هدي كمال فؤاد -->
                    <div class="doctor-card" data-type="اطفال" data-name="هدي كمال فؤاد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. هدي كمال فؤاد</h3>
                            <p class="spec">اخصائي أطفال</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(192 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 11 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">450 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('هدي كمال فؤاد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('هدي كمال فؤاد')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مروة اشرف يوسف -->
                    <div class="doctor-card" data-type="طبيعي" data-name="مروة اشرف يوسف">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مروة اشرف يوسف</h3>
                            <p class="spec">اخصائي علاج طبيعي</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(160 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 6 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">400 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مروة اشرف يوسف')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مروة اشرف يوسف')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. احمد حسن ابراهيم -->
                    <div class="doctor-card" data-type="اطفال" data-name="احمد حسن ابراهيم">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. احمد حسن ابراهيم</h3>
                            <p class="spec">اخصائي أطفال</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(203 تقييم)</span></p>
                            <p class="meta">📍 الإسكندرية، سموحة | 🕒 12 سنة خبرة</p>
                            <p class="price-status">● متاح غدا <span class="price">400 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('احمد حسن ابراهيم')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('احمد حسن ابراهيم')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مني علي السيد -->
                    <div class="doctor-card" data-type="جلدية" data-name="مني علي السيد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مني علي السيد</h3>
                            <p class="spec">اخصائي جلدية</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(156 تقييم)</span></p>
                            <p class="meta">📍 الجيزة، المهندسين | 🕒 10 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">600 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مني علي السيد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مني علي السيد')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. ياسمين احمد فؤاد -->
                    <div class="doctor-card" data-type="الولادة" data-name="ياسمين احمد فؤاد">
                        <div class="image-side">
                            <img src="../images/Doctor-Female.jpeg" alt="طبيبة" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. ياسمين احمد فؤاد</h3>
                            <p class="spec">اخصائي اطفال و حديثي الولادة</p>
                            <p class="rating">⭐ 4.9 <span class="rev-count">(150 تقييم)</span></p>
                            <p class="meta">📍 الجيزة، المهندسين | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">500 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('ياسمين احمد فؤاد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('ياسمين احمد فؤاد')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. محمود سعيد احمد -->
                    <div class="doctor-card" data-type="عظام" data-name="محمود سعيد احمد">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. محمود سعيد احمد</h3>
                            <p class="spec">جراح عظام</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(89 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مدينة نصر | 🕒 18 سنة خبرة</p>
                            <p class="price-status">● متاح بعد 3 أيام <span class="price">700 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('محمود سعيد احمد')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('محمود سعيد احمد')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. مصطفي خالد عبداللة -->
                    <div class="doctor-card" data-type="اذن وحنجرة" data-name="مصطفي خالد عبداللة">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. مصطفي خالد عبداللة</h3>
                            <p class="spec"> اخصائي انف واذن وحنجرة</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(120 تقييم)</span></p>
                            <p class="meta">📍 القاهرة، مدينة نصر | 🕒 10 سنة خبرة</p>
                            <p class="price-status">● متاح بعد 3 أيام <span class="price">600 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('مصطفي خالد عبداللة')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('مصطفي خالد عبداللة')">عرض الملف</button>
                        </div>
                    </div>

                    <!-- د. خالد فتحي عبدالله -->
                    <div class="doctor-card" data-type="اعصاب" data-name="خالد فتحي عبدالله">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. خالد فتحي عبدالله</h3>
                            <p class="spec">اخصائي أعصاب</p>
                            <p class="rating">⭐ 4.7 <span class="rev-count">(145 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">800 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('خالد فتحي عبدالله')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('خالد فتحي عبدالله')">عرض الملف</button>
                        </div>
                    </div>
                    <!-- د. شريف سامي حسن -->
                    <div class="doctor-card" data-type="دموية" data-name="شريف سامي حسن">
                        <div class="image-side">
                            <img src="../images/Doctor-Male.jpeg" alt="طبيب" class="doctor-img">
                        </div>
                        <div class="details-side">
                            <h3>د. شريف سامي حسن</h3>
                            <p class="spec">اخصائي قلب واوعية دموية</p>
                            <p class="rating">⭐ 4.8 <span class="rev-count">(160 تقييم)</span></p>
                            <p class="meta">📍 المنصورة، الجلاء | 🕒 9 سنوات خبرة</p>
                            <p class="price-status">● متاح اليوم <span class="price">900 جنيه</span></p>
                        </div>
                        <div class="actions-side">
                            <button class="btn-book" onclick="bookNow('شريف سامي حسن')">احجز الآن</button>
                            <button class="btn-profile" onclick="viewProfile('شريف سامي حسن')">عرض الملف</button>
                        </div>
                    </div>
                </div>
            </main>

        <?php } ?>
    </div>

    <!-- صفحة الملف الشخصي (مخفية في البداية) -->
    <div id="profilePage" style="display: none;">
        <div class="profile-container" id="profileContainer"></div>
    </div>

    <!-- بداية بوت المحادثة الذكي  -->
    <div class="chatbot-container" id="chatbotContainer">
        <!-- أيقونة البوت مع علامة الإشعار (Badge) -->
        <div class="chat-icon" id="chatIcon" onclick="toggleChat()">
            🤖
            <span class="badge" id="chatBadge">1</span>
        </div>
        <!-- نافذة المحادثة -->
        <div class="chat-window" id="chatWindow">
            <div class="chat-header">
                <span>المساعد الطبي</span>
                <button class="close-chat" onclick="toggleChat()">✖</button>
            </div>
            <div class="chat-messages" id="chatMessages">
                <div class="message bot-message">مرحباً! أنا مساعدك الطبي. كيف يمكنني مساعدتك اليوم؟</div>
            </div>
            <div class="chat-input-area">
                <input type="text" id="chatInput" placeholder="اكتب رسالتك..." onkeypress="if(event.key==='Enter') sendMessage()">
                <button onclick="sendMessage()">إرسال</button>
            </div>
        </div>
    </div>
    <!-- ========= نهاية البوت ========= -->

    <!-- كود الجافا سكريبت (الوظائف الأساسية + البوت) -->
    <script>
        // ----- بيانات الأطباء الكاملة -----
        const doctorsData = {
            'سارة محمد عبدالرحمن': {
                name: 'د. سارة محمد عبدالرحمن',
                specialty: 'اخصائي قلب',
                phone: '+20 112 345 6789',
                location: 'القاهرة، مصر الجديدة',
                price: '500 جنيه',
                rating: '4.9 (127 تقييم)',
                experience: '15 سنة',
                visitDate: 'الاثنين 15 مارس 2026',
                image: '../images/Doctor-Female.jpeg',
                schedule: [{
                        day: 'الأحد',
                        date: '14 مارس',
                        time: '10 ص - 2 م'
                    },
                    {
                        day: 'الثلاثاء',
                        date: '16 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '10 ص - 2 م'
                    },
                    {
                        day: 'السبت',
                        date: '20 مارس',
                        time: '2 م - 6 م'
                    }
                ]
            },
            'نهي يوسف محمود': {
                name: 'د. نهي يوسف محمود',
                specialty: 'طبيب عام',
                phone: '+20 115 678 1234',
                location: 'الإسكندرية، ميامي',
                price: '350 جنيه',
                rating: '4.9 (234 تقييم)',
                experience: '8 سنوات',
                visitDate: 'الأربعاء 17 مارس 2026',
                image: '../images/Doctor-Female.jpeg',
                schedule: [{
                        day: 'الإثنين',
                        date: '15 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '17 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'السبت',
                        date: '20 مارس',
                        time: '11 ص - 3 م'
                    }
                ]
            },
            'عمر محمد حجاب': {
                name: 'د. عمر محمد حجاب',
                specialty: 'اخصائي قلب',
                phone: '+20 122 333 4444',
                location: 'القاهرة، الزمالك',
                price: '650 جنيه',
                rating: '4.8 (178 تقييم)',
                experience: '20 سنة',
                visitDate: 'الثلاثاء 16 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الثلاثاء',
                        date: '16 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الجمعة',
                        date: '19 مارس',
                        time: '2 م - 6 م'
                    },
                    {
                        day: 'الأحد',
                        date: '21 مارس',
                        time: '10 ص - 2 م'
                    }
                ]
            },
            'هدي كمال فؤاد': {
                name: 'د. هدي كمال فؤاد',
                specialty: 'اخصائي أطفال',
                phone: '+20 106 543 2109',
                location: 'المنصورة، الجلاء',
                price: '450 جنيه',
                rating: '4.9 (192 تقييم)',
                experience: '11 سنة',
                visitDate: 'الخميس 18 مارس 2026',
                image: '../images/Doctor-Female.jpeg',
                schedule: [{
                        day: 'السبت',
                        date: '13 مارس',
                        time: '9 ص - 1 م'
                    },
                    {
                        day: 'الإثنين',
                        date: '15 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '17 مارس',
                        time: '9 ص - 1 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '4 م - 8 م'
                    }
                ]
            },
            'مروة اشرف يوسف': {
                name: 'د. مروة اشرف يوسف',
                specialty: 'اخصائي علاج طبيعي',
                phone: '+20 106 543 2109',
                location: 'المنصورة، الجلاء',
                price: '400 جنيه',
                rating: '4.9 (160 تقييم)',
                experience: '6 سنة',
                visitDate: 'الخميس 18 مارس 2026',
                image: '../images/Doctor-Female.jpeg',
                schedule: [{
                        day: 'السبت',
                        date: '13 مارس',
                        time: '9 ص - 1 م'
                    },
                    {
                        day: 'الإثنين',
                        date: '15 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '17 مارس',
                        time: '9 ص - 1 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '4 م - 8 م'
                    }
                ]
            },
            'احمد حسن ابراهيم': {
                name: 'د. احمد حسن ابراهيم',
                specialty: 'اخصائي أطفال',
                phone: '+20 114 567 8901',
                location: 'الإسكندرية، سموحة',
                price: '400 جنيه',
                rating: '4.8 (203 تقييم)',
                experience: '12 سنة',
                visitDate: 'السبت 20 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الأحد',
                        date: '14 مارس',
                        time: '10 ص - 2 م'
                    },
                    {
                        day: 'الثلاثاء',
                        date: '16 مارس',
                        time: '3 م - 7 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '10 ص - 2 م'
                    },
                    {
                        day: 'السبت',
                        date: '20 مارس',
                        time: '12 م - 4 م'
                    }
                ]
            },
            'ياسمين احمد فؤاد': {
                name: 'د. ياسمين احمد فؤاد',
                specialty: 'اخصائي اطفال و حديثي الولادة',
                phone: '+20 128 901 2345',
                location: 'الجيزة، المهندسين',
                price: '500 جنيه',
                rating: '4.9 (150 تقييم)',
                experience: '9 سنوات',
                visitDate: 'الأحد 14 مارس 2026',
                image: '../images/Doctor-Female.jpeg',
                schedule: [{
                        day: 'الأحد',
                        date: '14 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الثلاثاء',
                        date: '16 مارس',
                        time: '2 م - 6 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '17 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '18 مارس',
                        time: '4 م - 8 م'
                    }
                ]
            },

            'محمود سعيد احمد': {
                name: 'د. محمود سعيد احمد',
                specialty: 'جراح عظام',
                phone: '+20 127 654 3210',
                location: 'القاهرة، مدينة نصر',
                price: '700 جنيه',
                rating: '4.7 (89 تقييم)',
                experience: '18 سنة',
                visitDate: 'السبت 27 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الإثنين',
                        date: '22 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '24 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '25 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'السبت',
                        date: '27 مارس',
                        time: '10 ص - 2 م'
                    }
                ]
            },
            'مصطفي خالد عبداللة': {
                name: 'د. مصطفي خالد عبداللة',
                specialty: ' اخصائي انف واذن وحنجرة',
                phone: '+20 127 654 3210',
                location: 'القاهرة، مدينة نصر',
                price: '600 جنيه',
                rating: '4.7 (120 تقييم)',
                experience: '10 سنة',
                visitDate: 'السبت 27 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الإثنين',
                        date: '22 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '24 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '25 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'السبت',
                        date: '27 مارس',
                        time: '10 ص - 2 م'
                    }
                ]
            },
            'خالد فتحي عبدالله': {
                name: 'د. خالد فتحي عبدالله',
                specialty: 'اخصائي أعصاب',
                phone: '+20 110 987 6543',
                location: 'المنصورة، الجلاء',
                price: '800 جنيه',
                rating: '4.7 (145 تقييم)',
                experience: '9 سنوات',
                visitDate: 'الثلاثاء 23 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الأحد',
                        date: '21 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الثلاثاء',
                        date: '23 مارس',
                        time: '11 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '25 مارس',
                        time: '3 م - 7 م'
                    },
                    {
                        day: 'الجمعة',
                        date: '26 مارس',
                        time: '1 م - 5 م'
                    }
                ]
            },
            'شريف سامي حسن': {
                name: 'د. شريف سامي حسن',
                specialty: 'جراح قلب واوعية دموية',
                phone: '+20 127 654 3210',
                location: 'المنصورة،الجلاء',
                price: '900 جنيه',
                rating: '4.8 (160 تقييم)',
                experience: '9 سنة',
                visitDate: 'السبت 27 مارس 2026',
                image: '../images/Doctor-Male.jpeg',
                schedule: [{
                        day: 'الإثنين',
                        date: '22 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الأربعاء',
                        date: '24 مارس',
                        time: '9 ص - 3 م'
                    },
                    {
                        day: 'الخميس',
                        date: '25 مارس',
                        time: '4 م - 8 م'
                    },
                    {
                        day: 'السبت',
                        date: '27 مارس',
                        time: '10 ص - 2 م'
                    }
                ]
            },
        };


        // ----- دالة العودة للصفحة الرئيسية -----
        function goHome() {
            document.getElementById('profilePage').style.display = 'none';
            document.getElementById('homePage').style.display = 'block';
            document.getElementById('mainBody').classList.remove('profile-mode');
        }

        // ----- دالة الحجز (محاكاة) -----
        function bookNow(name) {
            alert("تم إرسال طلب الحجز للدكتور " + name + " بنجاح! سيتواصل معك فريق الموقع قريباً.");
        }

        function bookNows(name) {
            alert("تم إلغاء طلب الحجز للدكتور " + name + " بنجاح!");
        }

        // ----- دالة عرض الملف الشخصي -----
        function viewProfile(name) {
            const cleanName = name.trim();
            const doctorData = doctorsData[cleanName];
            if (doctorData) {
                displayProfilePage(doctorData);
            } else {
                alert('عذراً، لم يتم العثور على بيانات هذا الطبيب');
            }
        }

        // ----- دالة إنشاء صفحة الملف الشخصي -----
        function displayProfilePage(doctorData) {
            document.getElementById('homePage').style.display = 'none';
            document.getElementById('profilePage').style.display = 'block';
            document.getElementById('mainBody').classList.add('profile-mode');

            let scheduleHTML = '';
            doctorData.schedule.forEach(item => {
                scheduleHTML += `
                    <div class="schedule-item">
                        <div class="schedule-day">${item.day}</div>
                        <div class="schedule-date">${item.date}</div>
                        <div class="schedule-time">${item.time}</div>
                    </div>
                `;
            });

            document.getElementById('profileContainer').innerHTML = `
                <div class="profile-header">
                    <div class="profile-image-large">
                        <img src="${doctorData.image}" alt="${doctorData.name}">
                    </div>
                    <h2>${doctorData.name}</h2>
                    <p class="specialty-badge">${doctorData.specialty}</p>
                </div>
                <div class="profile-info">
                    <div class="info-row">
                        <span class="info-label">رقم الهاتف  :</span>
                        <span class="info-value phone">${doctorData.phone}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">العنوان  :</span>
                        <span class="info-value">${doctorData.location}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">سنوات الخبرة  :</span>
                        <span class="info-value">${doctorData.experience}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">حساب الكشف  :</span>
                        <span class="info-value price">${doctorData.price}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">التقييم  :</span>
                        <span class="info-value">${doctorData.rating}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">التاريخ  :</span>
                        <span class="info-value">${doctorData.visitDate}</span>
                    </div>
                </div>
                <div class="schedule-section">
                    <h3>مواعيد المتاحة</h3>
                    <div class="schedule-grid">
                        ${scheduleHTML}
                    </div>
                </div>
                <div class="profile-actions">
                    <button class="btn-back" onclick="goHome()">← العودة</button>
                    <button class="btn-book-large" onclick="bookNow('${doctorData.name}')">احجز الآن</button>
                    <button class="btn-book-large" onclick="bookNows('${doctorData.name}')">الغاء الحجز</button>
                </div>
            `;
        }

        // ----- دالة تصفية الأطباء حسب التخصص -----
        function filterSelection(type, btn) {
            const cards = document.getElementsByClassName("doctor-card");
            const buttons = document.getElementsByClassName("filter-btn");
            for (let b of buttons) b.classList.remove("active");
            btn.classList.add("active");
            for (let card of cards) {
                card.style.display = (type === "all" || card.getAttribute("data-type") === type) ? "flex" : "none";
            }
        }

        // ----- البحث بالاسم -----
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let cards = document.getElementsByClassName('doctor-card');
            for (let card of cards) {
                let name = card.getAttribute('data-name').toLowerCase();
                card.style.display = name.includes(filter) ? "flex" : "none";
            }
        });

        //  كود البوت الذكي 
        function toggleChat() {
            const chatWindow = document.getElementById('chatWindow');
            const badge = document.getElementById('chatBadge');
            if (chatWindow.style.display === 'none' || chatWindow.style.display === '') {
                chatWindow.style.display = 'flex';
                if (badge) badge.style.display = 'none'; // إخفاء البadge عند فتح المحادثة
            } else {
                chatWindow.style.display = 'none';
            }
        }

        function sendMessage() {
            const input = document.getElementById('chatInput');
            const messageText = input.value.trim();
            if (messageText === '') return;

            addMessage(messageText, 'user');
            setTimeout(() => {
                const reply = getAutoReply(messageText);
                addMessage(reply, 'bot');
            }, 500);
            input.value = '';
        }

        function addMessage(text, sender) {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', sender === 'user' ? 'user-message' : 'bot-message');
            messageDiv.textContent = text;
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function getAutoReply(userMessage) {
            const msg = userMessage.toLowerCase();

            // الكلمات المفتاحية للمواضيع غير الطبية
            const unrelatedKeywords = [
                'الاطباء'
            ];

            for (let keyword of unrelatedKeywords) {
                if (msg.includes(keyword)) {
                    return "عذرًا، أنا متخصص فقط في الاستفسارات الطبية وحجز الأطباء. هل تريد المساعدة في حجز طبيب أو الاستفسار عن التخصصات؟";
                }
            }

            // الردود الطبية
            if (msg.includes('السلام عليكم') || msg.includes('تحية') || msg.includes('مرحبا')) {
                return 'وعليكم السلام! كيف يمكنني مساعدتك في العثور على طبيب؟';
            } else if (msg.includes('السعر') || msg.includes('الأسعار') || msg.includes('التكلفة')) {
                return 'أسعار الكشف تبدأ من 350 جنيه حسب التخصص والطبيب. يمكنك الاطلاع على البطاقات لمعرفة التفاصيل.';
            } else if (msg.includes('احجز') || msg.includes('الحجز')) {
                return 'للحجز، اضغط على زر "احجز الآن" في بطاقة الطبيب الذي تريده.';
            } else if (msg.includes('الغاء') || msg.includes('الغاء')) {
                return 'للغاء، اضغط على زر "الغاء الحجز" في بطاقة الطبيب الذي تريده.';
            } else if (msg.includes('المواعيد') || msg.includes('المواعيد')) {
                return ' اضغط على زر " عرض الملف" في بطاقة الطبيب الذي تريده و سيظهر المواعيد ';
            } else if (msg.includes('اطفال') || msg.includes('الأطفال')) {
                return 'لدينا أطباء أطفال متميزون مثل د. هدي كمال ود. احمد حسن. يمكنك تصفية القائمة بالضغط على زر "اخصائي الأطفال".';
            } else if (msg.includes('قلب') || msg.includes('القلب')) {
                return 'أطباء القلب المتوفرون: د. سارة محمد ود. عمر محمد. تصفح القائمة لمعرفة المواعيد.';
            } else if (msg.includes('جلدية') || msg.includes('الجلدية')) {
                return 'الدكتورة مني علي متخصصة في الجلدية، يمكنك حجز موعد معها من خلال بطاقتها.';
            } else if (msg.includes('عظام') || msg.includes('العظام')) {
                return 'جراح العظام المتاح: د. محمود سعيد. تحقق من ملفه الشخصي للمواعيد.';
            } else if (msg.includes('قلب واوعية دموية') || msg.includes('القلب و اوعية دموية')) {
                return '  قلب واوعية دموية: د.شريف سامي. تحقق من ملفه الشخصي للمواعيد.';
            } else if (msg.includes('انف واذن وحنجرة') || msg.includes('الانف واذن وحنجرة')) {
                return '  انف واذن وحنجرة: د.مصطفي خالد. تحقق من ملفه الشخصي للمواعيد.';
            } else if (msg.includes('اطفال وحديثي الولادة') || msg.includes('الاطفال وحديثي الولادة')) {
                return '  اطفال وحديثي الولادة: د.ياسمين احمد فؤاد. تحقق من ملفه الشخصي للمواعيد.';
            } else if (msg.includes('علاج طبيعي') || msg.includes('العلاج الطبيعي')) {
                return '  علاج طبيعي: د.مروة اشرف. تحقق من ملفه الشخصي للمواعيد.';
            } else if (msg.includes('اعصاب') || msg.includes('الأعصاب')) {
                return 'د. خالد فتحي متخصص في الأعصاب. يمكنك الاطلاع على ملفه للحجز.';
            } else if (msg.includes('عام') || msg.includes('طبيب عام')) {
                return 'الدكتورة نهي يوسف طبيبة عامة متاحة للحجز. زر صفحتها للمزيد.';
            } else if (msg.includes('شكرا') || msg.includes('جزاك')) {
                return 'الشكر لله، نحن في خدمتك دائمًا.';
            } else if (msg.includes('التخصصات') || msg.includes('تخصص')) {
                return 'التخصصات المتوفرة: أطفال، قلب، أعصاب، جلدية، عظام، طب عام.';
            } else if (msg.includes('العودة') || msg.includes('الرئيسية')) {
                return 'يمكنك العودة للصفحة الرئيسية بالضغط على رابط "العودة للرئيسية" في الأعلى.';
            } else {
                return 'شكرًا لتواصلك. أنا هنا للإجابة عن استفساراتك حول الأطباء والمواعيد. هل تريد معرفة الأسعار أو التخصصات؟';
            }
        }
    </script>
</body>

</html>