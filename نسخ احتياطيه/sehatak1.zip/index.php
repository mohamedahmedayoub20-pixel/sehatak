<?php
include "includes/auth.php";
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sehatak - Home</title>
</head>

<body>
    <h1>Home</h1>
    <?php if (isLoggedIn()): ?>
        <p> Hello, <?php echo $_SESSION['user_email']; ?> | <?php echo $_SESSION['user_type']; ?> </p>
        <a href="logout.php">Logout</a>
        <a href="services.php">Services</a>
    <?php else: ?>
        <p> Your are browsing as guest. </p>
        <a href="login.php">Login</a>
    <?php endif; ?>

</body>

</html>