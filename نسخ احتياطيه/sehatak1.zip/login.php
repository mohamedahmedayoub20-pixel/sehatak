<?php

include "includes/auth.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email === "mohamed@gmail.com" && $password = "123") {
        $_SESSION['user_id'] = 1;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_type'] = 'Admin';

        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid credentials";
    }
} ?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <h1>Login</h1>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="post">
        <input name="email" type="email" require placeholder="Enter your email" />
        <br />
        <input name="password" type="password" require placeholder="Enter password" />
        <br />
        <button type="submit">Login</button>
        <a href="register.php">Create new account ?</a>
    </form>
</body>

</html>