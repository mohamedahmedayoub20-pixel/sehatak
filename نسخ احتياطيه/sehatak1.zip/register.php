<?php

include "includes/auth.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $passwordConfirm = $_POST['passwordConfirm'];
    $userType = $_POST['userType'];

    if (!isset($email)) {
        $error = "Email is required";
    }

    if (!isset($password)) {
        $error = "password is required";
    }

    if (!isset($passwordConfirm)) {
        $error = "password confirm is required";
    }

    if (isset($password) && isset($passwordConfirm) && $password != $passwordConfirm) {
        $error = "password != confirm password";
    }

    if (!isset($userType)) {
        $error = "user type is required";
    }

    if (!isset($error)) {
        $_SESSION['user_id'] = 2;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_type'] = $userType;
        header("Location: index.php");
        exit();
    }
    //dfdfdf

    /*
    dfgdfd

    ddfd
    fdf

    */
} ?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
</head>

<body>
    <h1>Create New Account</h1>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="post">
        <input name="email" type="email" require placeholder="Enter your email" />
        <br />
        <input name="password" type="password" require placeholder="Enter password" />
        <br />

        <input name="passwordConfirm" type="password" require placeholder="Renter password" />
        <br />
        <select name="userType">
            <option value="" disabled>Select account type</option>
            <option value="Patient">Patient</option>
            <option value="Doctor">Doctor</option>
            <option value="Nurse">Nurse</option>
            <option value="Medical Lap">Medical Lap</option>
            <option value="Pharmacy">Pharmacy</option>
        </select>
        <br />
        <!--fggfgfgfgfk
        dgdfdfd
        dfd
        fdf
        df
        df
        
        -->
        <button type="submit">Create</button>
        <a href="login.php">Have an account ?</a>
    </form>
</body>

</html>