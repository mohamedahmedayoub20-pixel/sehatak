<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "sehatak-new-db";

try { // PDO => PHP Data Objects
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
